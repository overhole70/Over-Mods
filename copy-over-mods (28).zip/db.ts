import { initializeApp } from "firebase/app";
import { 
  getFirestore,
  collection, 
  getDocs, 
  getDoc, 
  setDoc, 
  doc, 
  query, 
  updateDoc, 
  increment, 
  arrayUnion, 
  arrayRemove, 
  runTransaction, 
  where, 
  deleteDoc, 
  writeBatch, 
  onSnapshot,
  orderBy, 
  limit, 
  startAfter,
  QueryDocumentSnapshot,
  serverTimestamp, 
  Timestamp, 
  addDoc, 
  deleteField,
  Unsubscribe
} from "firebase/firestore";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  updateProfile,
  sendEmailVerification,
  sendPasswordResetEmail,
  updateEmail,
  GoogleAuthProvider,
  signInWithPopup,
  linkWithCredential,
  EmailAuthProvider
} from "firebase/auth";
import { Mod, ModType, AdminPermissions, User, UserRole, VerificationStatus, Notification, ModReport, ChatMessage, GameInvite, FriendRequest, NewsItem, Complaint, StaffMessage, MinecraftServer, Contest, QuestionProgress, QuestionChallenge, CommunityPost, PostComment, PopupWindowConfig } from "./types";

const firebaseConfig = {
  apiKey: "AIzaSyDiBxFISZbY3MveLqDo75T2ILMcH-BNEyQ",
  authDomain: "over-mods-d2d03.firebaseapp.com",
  projectId: "over-mods-d2d03",
  storageBucket: "over-mods-d2d03.firebasestorage.app",
  messagingSenderId: "460799504048",
  appId: "1:460799504048:web:4ff9fadce080bf1ff1d575"
};

const app = initializeApp(firebaseConfig);

// Initialize Firestore with standard settings (no experimental options)
export const firestore = getFirestore(app);

export const auth = getAuth(app);

let cachedIP: string | null = null;
let ipRequestPromise: Promise<string> | null = null;

const readCache: Record<string, { data: any, timestamp: number }> = {};
const CACHE_TTL = 30000; 

const COMMISSION_RATE = 0.15;
const PLATFORM_EMAIL = 'overmods1@gmail.com';

export class PlatformDB {
  /**
   * Sanitizes data for Firestore and prevents circular JSON errors.
   */
  private sanitizeData(obj: any, seen = new WeakSet()): any {
    if (obj === null || typeof obj !== 'object') return obj;
    
    // Handle specific types
    if (obj instanceof Date) return obj.toISOString();
    if (obj instanceof Timestamp) return obj.toDate().toISOString();
    if (obj instanceof File || obj instanceof Blob) return "[File/Blob]";
    
    // DOM/Event/Global checks
    if (obj instanceof Element || obj instanceof Event || (obj.nativeEvent && obj.preventDefault)) return "[DOM/Event Object]";
    if (typeof window !== 'undefined' && (obj === window || obj === document)) return "[Global Object]";

    // Circular check
    if (seen.has(obj)) return "[Circular Reference]";
    seen.add(obj);

    if (Array.isArray(obj)) {
      return obj.map(item => this.sanitizeData(item, seen));
    }
    
    // Check for non-plain objects, especially minified Firestore internals
    const proto = Object.getPrototypeOf(obj);
    if (proto && proto.constructor && proto.constructor.name !== 'Object' && proto.constructor.name !== 'Array') {
      const name = proto.constructor.name;
      // Minified class names are often 1 or 2 chars (e.g., 'Ka', 'Y')
      if (name.length <= 2 || '_firestore' in obj || 'firestore' in obj) {
         return "[Internal Object]"; 
      }
    }

    const sanitized: any = {};
    const keys = Object.keys(obj);
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const value = obj[key];
      if (value === undefined || typeof value === 'function') continue;
      // Skip private fields often used in libraries
      if (key.startsWith('_')) continue;
      sanitized[key] = this.sanitizeData(value, seen);
    }
    return sanitized;
  }

  async loginWithGoogle() {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userDoc = await getDoc(doc(firestore, 'users', user.uid));
      
      if (!userDoc.exists()) {
        const minimalUser = {
          id: user.uid,
          email: user.email,
          googleLinked: true,
          profileCompleted: false,
          createdAt: new Date().toISOString(),
          role: 'User',
          displayName: user.displayName || '',
          avatar: user.photoURL || ''
        };
        await setDoc(doc(firestore, 'users', user.uid), minimalUser);
        return { user: minimalUser, isNew: true };
      } else {
        const userData = userDoc.data();
        if (userData.profileCompleted === false) {
          return { user: { id: userDoc.id, ...userData }, isNew: true };
        }
        return { user: { id: userDoc.id, ...userData }, isNew: false };
      }
    } catch (error) {
      console.error("Google Sign-In Error:", error);
      throw error;
    }
  }

  async completeGoogleProfile(userId: string, data: { displayName: string, username: string, password?: string, avatarFile?: File }) {
    const cleanUsername = data.username.toLowerCase().trim();
    const email = auth.currentUser?.email;

    // Check restricted names
    if (this.isRestrictedName(data.displayName, email) || this.isRestrictedName(cleanUsername, email)) {
      throw new Error("عذراً، هذا الاسم محجوز للمسؤول فقط.");
    }

    const userQuery = query(collection(firestore, 'users'), where('username', '==', cleanUsername));
    const userSnap = await getDocs(userQuery);
    if (!userSnap.empty) {
        const existing = userSnap.docs[0];
        if (existing.id !== userId) throw new Error("اسم المستخدم هذا محجوز مسبقاً.");
    }

    if (data.password && auth.currentUser) {
        try {
          const credential = EmailAuthProvider.credential(auth.currentUser.email!, data.password);
          await linkWithCredential(auth.currentUser, credential);
        } catch (e) {
             console.warn("Link credential failed", e);
        }
    }

    let avatarData = '';
    if (data.avatarFile) {
        avatarData = await this.resizeImage(data.avatarFile, 400, 400);
    } else if (auth.currentUser?.photoURL) {
        avatarData = auth.currentUser.photoURL;
    }

    const updateData = {
        displayName: data.displayName,
        username: cleanUsername,
        avatar: avatarData,
        role: 'User',
        wallet: { gift: 10, earned: 0 },
        profileCompleted: true,
        verificationStatus: 'none',
        isVerified: false,
        numericId: Math.floor(1000000000 + Math.random() * 9000000000).toString(),
        privacySettings: { showInSearch: true, showFollowersList: true, showJoinDate: true, privateCollections: false, showOnlineStatus: true, messagingPermission: 'everyone' }
    };

    await updateDoc(doc(firestore, 'users', userId), this.sanitizeData(updateData));
    
    // Fraud check logic for wallet gift
    let deviceId = localStorage.getItem('device_fp');
    if (!deviceId) {
      deviceId = 'dev_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
      localStorage.setItem('device_fp', deviceId);
    }
    const ip = await this.getUserIP();
    let isFraud = false;
    try {
      const ipDoc = await getDoc(doc(firestore, 'fraud_registrations', ip.replace(/\./g, '_')));
      const devDoc = await getDoc(doc(firestore, 'fraud_registrations', deviceId));
      if (ipDoc.exists() || devDoc.exists()) isFraud = true;
    } catch (e) {}

    if (isFraud) {
       await updateDoc(doc(firestore, 'users', userId), { 'wallet.gift': 0 });
    } else {
       try {
         await setDoc(doc(firestore, 'fraud_registrations', ip.replace(/\./g, '_')), { userId: userId, timestamp: serverTimestamp() });
         await setDoc(doc(firestore, 'fraud_registrations', deviceId), { userId: userId, timestamp: serverTimestamp() });
       } catch (e) {}
    }
    
    return { id: userId, ...updateData };
  }

  async get(coll: string, id: string) {
    const cacheKey = `${coll}_${id}`;
    const now = Date.now();
    if (readCache[cacheKey] && (now - readCache[cacheKey].timestamp < CACHE_TTL)) return readCache[cacheKey].data;
    try {
      const docSnap = await getDoc(doc(firestore, coll, id));
      if (!docSnap.exists()) return null;
      const data = { id: docSnap.id, ...docSnap.data() };
      readCache[cacheKey] = { data, timestamp: now };
      return data;
    } catch (e) { return null; }
  }

  async put(coll: string, data: any) {
    const id = data.id || (data.title ? data.title.replace(/\s+/g, '-').toLowerCase() + Date.now() : 'id_' + Date.now());
    await setDoc(doc(firestore, coll, id), this.sanitizeData({ ...data, id }), { merge: true });
    delete readCache[`${coll}_${id}`];
  }

  async getAll(coll: string, limitCount?: number) {
    let q = query(collection(firestore, coll), orderBy('createdAt', 'desc'));
    if (limitCount) q = query(q, limit(limitCount));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  }

  async getModsPaginated(limitCount: number = 10, lastDoc?: QueryDocumentSnapshot) {
    let q = query(collection(firestore, 'mods'), orderBy('createdAt', 'desc'), limit(limitCount));
    if (lastDoc) {
      q = query(q, startAfter(lastDoc));
    }
    const snap = await getDocs(q);
    return {
      mods: snap.docs.map(d => ({ id: d.id, ...d.data() } as Mod)),
      lastDoc: snap.docs[snap.docs.length - 1] || null
    };
  }

  async getUserMods(userId: string): Promise<Mod[]> {
    const q = query(collection(firestore, 'mods'), where('publisherId', '==', userId));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as Mod));
  }

  async getAllUsers(limitCount?: number, lastDoc?: QueryDocumentSnapshot) {
    let q = query(collection(firestore, 'users'), orderBy('createdAt', 'desc'));
    if (limitCount && limitCount > 0) {
      q = query(q, limit(limitCount));
    }
    if (lastDoc) {
      q = query(q, startAfter(lastDoc));
    }
    const snap = await getDocs(q);
    return {
      users: snap.docs.map(d => d.data() as User),
      lastDoc: snap.docs[snap.docs.length - 1] || null
    };
  }

  // Optimized Search: Uses database index instead of fetching all users
  async searchUsers(term: string): Promise<User[]> {
    const cleanTerm = term.toLowerCase().trim();
    if (!cleanTerm) return [];
    
    // We try multiple queries to cover different fields
    // Note: Firestore doesn't support OR queries across different fields efficiently without multiple queries
    // We will prioritize username search, then numericId, then displayName
    
    const results = new Map<string, User>();
    
    try {
      // 1. Username Prefix Search
      const qUsername = query(
        collection(firestore, 'users'),
        orderBy('username'),
        where('username', '>=', cleanTerm),
        where('username', '<=', cleanTerm + '\uf8ff')
      );
      
      // 2. Numeric ID Exact Match (if term is numeric)
      let qNumeric = null;
      if (/^\d+$/.test(cleanTerm)) {
         qNumeric = query(collection(firestore, 'users'), where('numericId', '==', cleanTerm), limit(1));
      }

      // 3. Display Name Prefix Search (requires index on displayName)
      // Note: Case-sensitive usually, but we can try. 
      // Ideally we should store lowercaseDisplayName for search.
      // For now, we'll skip displayName prefix search to avoid index errors or case issues, 
      // or we can try exact match if needed.
      // Let's stick to username and numericId as primary reliable search methods.
      
      const promises = [getDocs(qUsername)];
      if (qNumeric) promises.push(getDocs(qNumeric));
      
      const snapshots = await Promise.all(promises);
      
      snapshots.forEach(snap => {
        snap.docs.forEach(d => {
           results.set(d.id, d.data() as User);
        });
      });
      
    } catch (e) {
      console.warn("Search users failed", e);
    }
    
    return Array.from(results.values());
  }

  async getPendingVerifications(): Promise<User[]> {
    const q = query(collection(firestore, 'users'), where('verificationStatus', '==', 'pending'));
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as User);
  }

  async getUserIP(): Promise<string> {
    if (cachedIP) return cachedIP;
    if (ipRequestPromise) return ipRequestPromise;
    
    const fetchWithTimeout = (url: string, ms: number) => {
        const controller = new AbortController();
        const promise = fetch(url, { signal: controller.signal });
        const timeout = setTimeout(() => controller.abort(), ms);
        return promise.finally(() => clearTimeout(timeout));
    };

    ipRequestPromise = fetchWithTimeout('https://api.ipify.org?format=json', 3000)
      .then(res => {
        if (!res.ok) throw new Error('Network response was not ok');
        return res.json();
      })
      .then(data => { cachedIP = data.ip; return data.ip; })
      .catch((e) => {
        console.warn("IP Fetch failed, using fallback", e);
        return "guest_" + Math.random().toString(36).substr(2, 9);
      })
      .finally(() => { ipRequestPromise = null; });
      
    return ipRequestPromise;
  }

  // --- Views Logic ---
  async incrementViews(modId: string, ip: string) {
    const userId = auth.currentUser?.uid || 'guest';
    const deviceId = localStorage.getItem('device_fp') || 'unknown_device';
    const logId = `${modId}_${userId}_${ip.replace(/\./g, '_')}`;
    const logRef = doc(firestore, 'mod_view_logs', logId);
    const modRef = doc(firestore, 'mods', modId);
    try {
      await runTransaction(firestore, async (transaction) => {
        const modSnap = await transaction.get(modRef);
        if (!modSnap.exists()) return;
        const modData = modSnap.data();
        const logSnap = await transaction.get(logRef);
        if (!logSnap.exists()) {
          transaction.set(logRef, { modId, userId, ip, deviceId, timestamp: serverTimestamp() });
          if (!modData.stats) {
             transaction.set(modRef, { stats: { views: 1, uniqueViews: 1, downloads: 0, likes: 0, dislikes: 0, ratingCount: 0, averageRating: 0, totalRatingScore: 0 } }, { merge: true });
          } else {
             transaction.update(modRef, { 'stats.views': increment(1), 'stats.uniqueViews': increment(1) });
          }
          const publisherId = modData.publisherId;
          if (publisherId) {
             const currentTotalViews = modData.stats?.views || 0;
             let pointsToAdd = 0.1;
             const bonusProbability = 0.05 / (1 + (currentTotalViews * 0.0001)); 
             if (Math.random() < bonusProbability) pointsToAdd = Math.random() < 0.2 ? 0.7 : 0.5;
             const publisherRef = doc(firestore, 'users', publisherId);
             // Wrap in try-catch to ignore permission errors for updating other users
             try {
                transaction.update(publisherRef, { 'wallet.earned': increment(pointsToAdd) });
             } catch (e) {
                // Ignore permission error if we can't update publisher wallet
             }
          }
        } else {
          if (!modData.stats) {
             transaction.set(modRef, { stats: { views: 1, uniqueViews: 0, downloads: 0, likes: 0, dislikes: 0, ratingCount: 0, averageRating: 0, totalRatingScore: 0 } }, { merge: true });
          } else {
             transaction.update(modRef, { 'stats.views': increment(1) });
          }
        }
      });
    } catch (e: any) { 
       if (e.code !== 'permission-denied') {
          console.error("Increment view transaction failed", e); 
       }
    }
  }

  async incrementDownloads(modId: string, ip: string) {
    const modRef = doc(firestore, 'mods', modId);
    try {
      await runTransaction(firestore, async (tx) => {
          const snap = await tx.get(modRef);
          if (!snap.exists()) return;
          const data = snap.data();
          if (!data.stats) {
              tx.set(modRef, { stats: { views: 0, uniqueViews: 0, downloads: 1, likes: 0, dislikes: 0 } }, { merge: true });
          } else {
              tx.update(modRef, { 'stats.downloads': increment(1) });
          }
      });
    } catch (e: any) {
       if (e.code !== 'permission-denied') {
          console.error("Increment download failed", e);
       }
    }
  }

  // --- FAKE STATS LOGIC ---
  async updateModFakeStats(modId: string, fakeStats: { views?: number; downloads?: number; likes?: number }) {
    const modRef = doc(firestore, 'mods', modId);
    await updateDoc(modRef, { fakeStats });
  }

  async resetModFakeStats(modId: string) {
    const modRef = doc(firestore, 'mods', modId);
    await updateDoc(modRef, { fakeStats: deleteField() });
  }

  async updatePostFakeLikes(postId: string, count: number) {
    const postRef = doc(firestore, 'community_posts', postId);
    await updateDoc(postRef, { fakeLikes: count });
  }

  async resetPostFakeLikes(postId: string) {
    const postRef = doc(firestore, 'community_posts', postId);
    await updateDoc(postRef, { fakeLikes: deleteField() });
  }

  // --- POPUP SYSTEM ---
  async updatePopupSettings(config: PopupWindowConfig) {
    await setDoc(doc(firestore, 'settings', 'popup_window'), config);
  }

  // --- Auth & User ---
  // --- Helper for Restricted Names ---
  isRestrictedName(name: string, email?: string | null) {
    if (email === 'overmods1@gmail.com') return false;
    const forbidden = ['over mods', 'over_mods', 'overmods'];
    const lower = name.toLowerCase();
    return forbidden.some(f => lower.includes(f));
  }

  async register(email: string | null, pass: string, displayName: string, username: string, avatarFile: File) {
    const cleanUsername = username.toLowerCase().trim();
    
    // Check restricted names
    if (this.isRestrictedName(displayName, email) || this.isRestrictedName(cleanUsername, email)) {
      throw new Error("عذراً، هذا الاسم محجوز للمسؤول فقط.");
    }

    try {
      const userQuery = query(collection(firestore, 'users'), where('username', '==', cleanUsername));
      const userSnap = await getDocs(userQuery);
      if (!userSnap.empty) {
        throw new Error("اسم المستخدم هذا محجوز مسبقاً. يرجى اختيار اسم آخر.");
      }
    } catch (e: any) {
      if (e.message.includes("اسم المستخدم")) throw e;
      console.warn("Username check skipped due to permissions or error:", e);
    }

    let deviceId = localStorage.getItem('device_fp');
    if (!deviceId) {
      deviceId = 'dev_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
      localStorage.setItem('device_fp', deviceId);
    }
    const ip = await this.getUserIP();
    let isFraud = false;
    try {
      const ipDoc = await getDoc(doc(firestore, 'fraud_registrations', ip.replace(/\./g, '_')));
      const devDoc = await getDoc(doc(firestore, 'fraud_registrations', deviceId));
      if (ipDoc.exists() || devDoc.exists()) isFraud = true;
    } catch (e) { console.warn("Fraud check error", e); }

    const isEmailRegister = email && email.trim().length > 0;
    const authEmail = isEmailRegister ? email! : `u${Date.now()}${Math.floor(Math.random()*1000)}@noemail.overmods.com`;

    const result = await createUserWithEmailAndPassword(auth, authEmail, pass);
    
    let avatarData = '';
    if (avatarFile) {
        avatarData = await this.resizeImage(avatarFile, 400, 400);
    }
    
    if (!avatarData || avatarData.length === 0) {
        avatarData = "https://ui-avatars.com/api/?background=random&name=" + encodeURIComponent(displayName);
    }

    await updateProfile(result.user, { displayName });
    const giftPoints = isFraud ? 0 : 10;
    
    const userData: User = {
      id: result.user.uid,
      numericId: Math.floor(1000000000 + Math.random() * 9000000000).toString(),
      displayName,
      username: cleanUsername,
      email: isEmailRegister ? authEmail : undefined,
      avatar: avatarData,
      followers: 0,
      following: [],
      blockedUsers: [],
      role: 'User',
      isBlocked: false,
      verificationStatus: 'none',
      isVerified: false,
      createdAt: new Date().toISOString(),
      privacySettings: { showInSearch: true, showFollowersList: true, showJoinDate: true, privateCollections: false, showOnlineStatus: true, messagingPermission: 'everyone' },
      wallet: { gift: giftPoints, earned: 0 }
    };
    
    await setDoc(doc(firestore, 'users', result.user.uid), this.sanitizeData({ ...userData, authEmail }));
    
    if (!isFraud) {
       try {
         await setDoc(doc(firestore, 'fraud_registrations', ip.replace(/\./g, '_')), { userId: result.user.uid, timestamp: serverTimestamp() });
         await setDoc(doc(firestore, 'fraud_registrations', deviceId), { userId: result.user.uid, timestamp: serverTimestamp() });
       } catch (e) {}
    }
    
    if (isEmailRegister) {
      try {
        await sendEmailVerification(result.user);
      } catch (e) { console.warn("Verification email failed", e); }
    }
    
    return userData;
  }

  async checkAndInitWallet(userId: string) {
    const userRef = doc(firestore, 'users', userId);
    const userSnap = await getDoc(userRef);
    if (!userSnap.exists()) return;
    const userData = userSnap.data() as User;
    if (userData.wallet) return;
    let deviceId = localStorage.getItem('device_fp');
    if (!deviceId) {
      deviceId = 'dev_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
      localStorage.setItem('device_fp', deviceId);
    }
    const ip = await this.getUserIP();
    let isFraud = false;
    try {
      const ipDoc = await getDoc(doc(firestore, 'fraud_registrations', ip.replace(/\./g, '_')));
      const devDoc = await getDoc(doc(firestore, 'fraud_registrations', deviceId));
      if (ipDoc.exists() || devDoc.exists()) isFraud = true;
    } catch (e) {}
    const giftPoints = isFraud ? 0 : 10;
    await updateDoc(userRef, { wallet: { gift: giftPoints, earned: 0 } });
    if (!isFraud) {
       try {
         await setDoc(doc(firestore, 'fraud_registrations', ip.replace(/\./g, '_')), { userId: userId, timestamp: serverTimestamp() });
         await setDoc(doc(firestore, 'fraud_registrations', deviceId), { userId: userId, timestamp: serverTimestamp() });
       } catch (e) {}
    }
    delete readCache[`users_${userId}`];
  }

  async checkOwnerRules(user: User) {
    if (user.email !== PLATFORM_EMAIL) return;
    const now = Date.now();
    const lastGrant = user.lastOwnerGrant ? new Date(user.lastOwnerGrant).getTime() : 0;
    const fiveDays = 5 * 24 * 60 * 60 * 1000;
    const initialBalance = 1000000;
    const userRef = doc(firestore, 'users', user.id);
    if (!user.lastOwnerGrant) { await updateDoc(userRef, { 'wallet.earned': increment(initialBalance), lastOwnerGrant: new Date().toISOString() }); return; }
    if (now - lastGrant >= fiveDays) { await updateDoc(userRef, { 'wallet.earned': increment(initialBalance), lastOwnerGrant: new Date().toISOString() }); }
  }

  // ... (Community Post Methods remain mostly same)
  async createCommunityPost(post: Omit<CommunityPost, 'id' | 'createdAt' | 'likes' | 'comments'>) {
    const data: CommunityPost = {
      ...post,
      id: `post_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString(),
      likes: [],
      comments: []
    };
    await this.put('community_posts', data);
  }

  async getCommunityPosts(limitCount: number = 20, lastDoc?: QueryDocumentSnapshot) {
    let q = query(collection(firestore, 'community_posts'), orderBy('createdAt', 'desc'), limit(limitCount));
    if (lastDoc) {
      q = query(q, startAfter(lastDoc));
    }
    const snap = await getDocs(q);
    const now = new Date();
    const posts: CommunityPost[] = [];
    const expiredIds: string[] = [];

    snap.forEach(d => {
      const data = { id: d.id, ...d.data() } as CommunityPost;
      if (new Date(data.expiresAt) > now) {
        posts.push(data);
      } else {
        expiredIds.push(d.id);
      }
    });

    if (expiredIds.length > 0) {
      const batch = writeBatch(firestore);
      expiredIds.forEach(id => batch.delete(doc(firestore, 'community_posts', id)));
      batch.commit().catch(e => console.error("Cleanup error", e));
    }

    return {
      posts,
      lastDoc: snap.docs[snap.docs.length - 1] || null
    };
  }

  async likeCommunityPost(postId: string, userId: string) {
    const ref = doc(firestore, 'community_posts', postId);
    await runTransaction(firestore, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const data = snap.data() as CommunityPost;
      const likes = data.likes || [];
      if (likes.includes(userId)) {
        tx.update(ref, { likes: arrayRemove(userId) });
      } else {
        tx.update(ref, { likes: arrayUnion(userId) });
      }
    });
  }

  async commentOnPost(postId: string, comment: PostComment) {
    const ref = doc(firestore, 'community_posts', postId);
    await updateDoc(ref, { comments: arrayUnion(this.sanitizeData(comment)) });
  }

  async deletePostComment(postId: string, comment: PostComment) {
    const ref = doc(firestore, 'community_posts', postId);
    await runTransaction(firestore, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const data = snap.data() as CommunityPost;
      const newComments = (data.comments || []).filter(c => c.id !== comment.id);
      tx.update(ref, { comments: newComments });
    });
  }

  async likePostComment(postId: string, commentId: string, userId: string) {
    const ref = doc(firestore, 'community_posts', postId);
    await runTransaction(firestore, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const data = snap.data() as CommunityPost;
      const comments = data.comments || [];
      const commentIndex = comments.findIndex(c => c.id === commentId);
      if (commentIndex === -1) return;
      const comment = comments[commentIndex];
      const likes = comment.likes || [];
      let newLikes = [...likes];
      if (likes.includes(userId)) {
        newLikes = newLikes.filter(id => id !== userId);
      } else {
        newLikes.push(userId);
      }
      comments[commentIndex] = { ...comment, likes: newLikes };
      tx.update(ref, { comments: comments });
    });
  }

  async deleteCommunityPost(postId: string) {
    await deleteDoc(doc(firestore, 'community_posts', postId));
  }

  async transferPoints(senderId: string, recipientIdentifier: string, amount: number) {
     if (amount <= 0) throw new Error("Amount must be positive");
     const usersRef = collection(firestore, 'users');
     const qNumeric = query(usersRef, where('numericId', '==', recipientIdentifier));
     const snapNumeric = await getDocs(qNumeric);
     let recipientId = '';
     if (!snapNumeric.empty) { recipientId = snapNumeric.docs[0].id; } 
     else { const docSnap = await getDoc(doc(firestore, 'users', recipientIdentifier)); if (docSnap.exists()) recipientId = docSnap.id; }
     if (!recipientId) throw new Error("Recipient not found");
     if (recipientId === senderId) throw new Error("Cannot send points to yourself");
     const senderRef = doc(firestore, 'users', senderId);
     const recipientRef = doc(firestore, 'users', recipientId);
     await runTransaction(firestore, async (transaction) => {
        const senderSnap = await transaction.get(senderRef);
        if (!senderSnap.exists()) throw new Error("Sender not found");
        const senderData = senderSnap.data() as User;
        const currentEarned = senderData.wallet?.earned || 0;
        if (currentEarned < amount) throw new Error("Insufficient earned balance. Gift points cannot be transferred.");
        transaction.update(senderRef, { 'wallet.earned': increment(-amount) });
        transaction.update(recipientRef, { 'wallet.earned': increment(amount) });
        const txRef = doc(collection(firestore, 'transactions'));
        transaction.set(txRef, { senderId, recipientId, amount, type: 'transfer', timestamp: serverTimestamp() });
     });
     await this.sendNotification(recipientId, "استلام نقاط", `لقد استلمت ${amount} نقطة من ${senderId === auth.currentUser?.uid ? 'مستخدم' : 'صديق'}`, 'points', 'Wallet');
  }

  async createContest(data: { title: string; description: string; rewardPoints: number; numberOfWinners: number }) { await this.put('contests', { ...data, participants: [], status: 'active', createdAt: new Date().toISOString() }); }
  async joinContest(contestId: string, userId: string) { const contestRef = doc(firestore, 'contests', contestId); await updateDoc(contestRef, { participants: arrayUnion(userId) }); }
  async endContest(contestId: string) {
    const contestRef = doc(firestore, 'contests', contestId);
    await runTransaction(firestore, async (transaction) => {
      const snap = await transaction.get(contestRef);
      if (!snap.exists()) throw new Error("Contest not found");
      const contest = snap.data() as Contest;
      if (contest.status !== 'active') throw new Error("Contest already ended");
      const participants = contest.participants || [];
      const numWinners = Math.min(contest.numberOfWinners, participants.length);
      const winners: { userId: string; displayName: string; avatar: string }[] = [];
      if (numWinners > 0) {
        const shuffled = [...participants].sort(() => 0.5 - Math.random());
        const winnerIds = shuffled.slice(0, numWinners);
        for (const uid of winnerIds) {
          const userSnap = await getDoc(doc(firestore, 'users', uid));
          if (userSnap.exists()) {
            const u = userSnap.data() as User;
            winners.push({ userId: u.id, displayName: u.displayName, avatar: u.avatar });
            transaction.update(doc(firestore, 'users', uid), { 'wallet.earned': increment(contest.rewardPoints) });
          }
        }
      }
      transaction.update(contestRef, { status: 'ended', winners: winners });
    });
  }
  async getContests(): Promise<Contest[]> { const snap = await getDocs(query(collection(firestore, 'contests'), orderBy('createdAt', 'desc'))); return snap.docs.map(d => ({ id: d.id, ...d.data() } as Contest)); }
  async saveQuestionProgress(userId: string, progress: QuestionProgress) { await updateDoc(doc(firestore, 'users', userId), { questionProgress: progress }); }
  async createQuestionChallenge(sender: User, receiverId: string, difficulty: string, questionCount: number): Promise<string> {
    const receiverSnap = await getDoc(doc(firestore, 'users', receiverId)); if (!receiverSnap.exists()) throw new Error("Receiver not found"); const receiver = receiverSnap.data() as User;
    const challenge: QuestionChallenge = { id: '', senderId: sender.id, senderName: sender.displayName, senderAvatar: sender.avatar, receiverId: receiver.id, receiverName: receiver.displayName, receiverAvatar: receiver.avatar, difficulty, questionCount, status: 'pending', senderScore: { correct: 0, wrong: 0, finished: false }, receiverScore: { correct: 0, wrong: 0, finished: false }, createdAt: new Date().toISOString() };
    const ref = doc(collection(firestore, 'question_challenges')); challenge.id = ref.id; await setDoc(ref, challenge); return challenge.id;
  }
  async acceptQuestionChallenge(challengeId: string) { await updateDoc(doc(firestore, 'question_challenges', challengeId), { status: 'accepted' }); }
  async updateChallengeScore(challengeId: string, userId: string, correct: number, wrong: number, finished: boolean) {
    const ref = doc(firestore, 'question_challenges', challengeId);
    await runTransaction(firestore, async (tx) => {
      const snap = await tx.get(ref); if (!snap.exists()) return; const data = snap.data() as QuestionChallenge;
      if (data.senderId === userId) tx.update(ref, { senderScore: { correct, wrong, finished } }); else if (data.receiverId === userId) tx.update(ref, { receiverScore: { correct, wrong, finished } });
      const senderFinished = (data.senderId === userId) ? finished : data.senderScore.finished; const receiverFinished = (data.receiverId === userId) ? finished : data.receiverScore.finished;
      if (senderFinished && receiverFinished) tx.update(ref, { status: 'finished' });
    });
  }
  async adminDistributePoints(recipientId: string, amount: number) { const recipientRef = doc(firestore, 'users', recipientId); await updateDoc(recipientRef, { 'wallet.earned': increment(amount) }); await this.sendNotification(recipientId, "مكافأة خاصة", `لقد استلمت ${amount} نقطة من إدارة المنصة!`, 'points', 'Gift'); }
  
  async login(identifier: string, pass: string) { 
    let loginEmail = identifier;
    if (!identifier.includes('@')) {
      const q = query(collection(firestore, 'users'), where('username', '==', identifier.toLowerCase().trim()));
      const snap = await getDocs(q);
      if (snap.empty) throw new Error("اسم المستخدم غير موجود");
      const data = snap.docs[0].data();
      loginEmail = data.authEmail || data.email;
      if (!loginEmail) throw new Error("بيانات الدخول غير صالحة");
    }

    try {
      const credentials = await signInWithEmailAndPassword(auth, loginEmail, pass); 
      
      await updateDoc(doc(firestore, 'users', credentials.user.uid), { 
        loginCount: increment(1),
        loginsSinceLastCode: increment(1) 
      });
      
      const userSnap = await getDoc(doc(firestore, 'users', credentials.user.uid)); 
      if (userSnap.exists()) await this.checkOwnerRules({ id: userSnap.id, ...userSnap.data() } as User); 
      return credentials.user; 
    } catch (e: any) {
      console.error("Login Error:", e.code, e.message);
      if (e.code === 'auth/user-not-found' || e.code === 'auth/invalid-credential' || e.code === 'auth/wrong-password') {
        throw new Error("اسم المستخدم أو كلمة المرور غير صحيحة");
      } else if (e.code === 'auth/network-request-failed') {
        throw new Error("فشل الاتصال بالخادم. يرجى التحقق من الإنترنت.");
      } else if (e.code === 'auth/too-many-requests') {
        throw new Error("محاولات كثيرة خاطئة. يرجى الانتظار قليلاً.");
      }
      throw new Error(e.message || "حدث خطأ أثناء تسجيل الدخول");
    }
  }

  async logout() { await signOut(auth); }
  async updateAccount(userId: string, data: Partial<User>) {
    const email = auth.currentUser?.email;
    if (data.displayName && this.isRestrictedName(data.displayName, email)) {
       throw new Error("عذراً، هذا الاسم محجوز للمسؤول فقط.");
    }
    if (data.username && this.isRestrictedName(data.username, email)) {
       throw new Error("عذراً، هذا الاسم محجوز للمسؤول فقط.");
    }
    await updateDoc(doc(firestore, 'users', userId), this.sanitizeData(data));
    delete readCache[`users_${userId}`];
  }
  
  async resizeImage(file: File, maxWidth = 800, maxHeight = 800): Promise<string> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          try {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            if (width > height) {
              if (width > maxWidth) {
                height *= maxWidth / width;
                width = maxWidth;
              }
            } else {
              if (height > maxHeight) {
                width *= maxHeight / height;
                height = maxHeight;
              }
            }
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                resolve(e.target?.result as string || "");
                return;
            }
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', 0.7));
          } catch (err) {
            resolve(e.target?.result as string || "");
          }
        };
        img.onerror = () => { resolve(""); };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => { resolve(""); };
      reader.readAsDataURL(file);
    });
  }

  generateShareCode(type: string): string { const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let code = type.charAt(0).toUpperCase(); for (let i = 0; i < 5; i++) code += chars.charAt(Math.floor(Math.random() * chars.length)); return code; }
  async getNotifications(userId: string): Promise<Notification[]> { 
    try {
      const q = query(collection(firestore, 'notifications'), where('userId', '==', userId)); 
      const snap = await getDocs(q); 
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Notification)).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); 
    } catch (e) { return []; }
  }
  async markNotificationRead(id: string) { try { await updateDoc(doc(firestore, 'notifications', id), { isRead: true }); } catch (e) {} }
  async deleteNotification(id: string) { try { await deleteDoc(doc(firestore, 'notifications', id)); } catch (e) {} }
  async deleteAllNotifications(userId: string) { try { const q = query(collection(firestore, 'notifications'), where('userId', '==', userId)); const snap = await getDocs(q); const batch = writeBatch(firestore); snap.docs.forEach(d => batch.delete(d.ref)); await batch.commit(); } catch (e) {} }
  async sendNotification(userId: string, title: string, message: string, type: string, icon?: string, scheduledAt?: string) { try { await this.put('notifications', { userId, title, message, type, icon, isRead: false, createdAt: new Date().toISOString(), scheduledAt }); } catch (e) {} }
  async getReportsForPublisher(publisherId: string): Promise<ModReport[]> { 
    try {
      const q = query(collection(firestore, 'reports'), where('publisherId', '==', publisherId)); 
      const snap = await getDocs(q); 
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as ModReport)).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); 
    } catch (e) { return []; }
  }
  async resolveReport(id: string) { try { await updateDoc(doc(firestore, 'reports', id), { status: 'reviewed' }); } catch (e) {} }
  async deleteReport(id: string) { try { await deleteDoc(doc(firestore, 'reports', id)); } catch (e) {} }
  async deleteMod(id: string) { try { await deleteDoc(doc(firestore, 'mods', id)); } catch (e) {} }
  async followUser(followerId: string, followingId: string) { const userRef = doc(firestore, 'users', followerId); const targetRef = doc(firestore, 'users', followingId); try { await runTransaction(firestore, async (tx) => { const uSnap = await tx.get(userRef); if (!uSnap.exists()) return; const following = uSnap.data().following || []; if (following.includes(followingId)) { tx.update(userRef, { following: arrayRemove(followingId) }); tx.update(targetRef, { followers: increment(-1) }); } else { tx.update(userRef, { following: arrayUnion(followingId) }); tx.update(targetRef, { followers: increment(1) }); } }); } catch (e) {} }
  onAuthChange(callback: (user: any) => void) { return onAuthStateChanged(auth, callback); }
  
  async getFollowers(userId: string): Promise<User[]> {
    try {
      const q = query(collection(firestore, 'users'), where('following', 'array-contains', userId));
      const snap = await getDocs(q);
      return snap.docs.map(d => d.data() as User);
    } catch (e) { return []; }
  }

  async banUser(userId: string, durationDays: number, reason: string) {
    const blockedUntil = new Date();
    blockedUntil.setDate(blockedUntil.getDate() + durationDays);
    try {
      await updateDoc(doc(firestore, 'users', userId), { isBlocked: true, blockedReason: reason, blockedUntil: blockedUntil.toISOString() });
    } catch (e) {}
  }

  async unbanUser(userId: string) { try { await updateDoc(doc(firestore, 'users', userId), { isBlocked: false, blockedReason: null, blockedUntil: null }); } catch (e) {} }
  async deleteUser(userId: string) { try { await deleteDoc(doc(firestore, 'users', userId)); } catch (e) {} }
  async resolveVerification(userId: string, status: VerificationStatus) { const update: any = { verificationStatus: status }; if (status === 'verified') update.isVerified = true; else if (status === 'none') update.isVerified = false; try { await updateDoc(doc(firestore, 'users', userId), update); } catch (e) {} }
  async updateAuthEmail(email: string) { if (auth.currentUser) { try { await updateEmail(auth.currentUser, email); } catch (e) {} } }
  async scheduleAccountDeletion(userId: string) { try { await updateDoc(doc(firestore, 'users', userId), { scheduledDeletion: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() }); } catch (e) {} }
  
  async getRecentChats(userId: string): Promise<string[]> {
    try {
      // Queries without orderBy('createdAt') to avoid complex index requirements
      const sentQ = query(collection(firestore, 'messages'), where('senderId', '==', userId), limit(50));
      const receivedQ = query(collection(firestore, 'messages'), where('receiverId', '==', userId), limit(50));
      
      const [sentSnap, receivedSnap] = await Promise.all([getDocs(sentQ), getDocs(receivedQ)]);
      const partners = new Set<string>();
      
      // Sort logic moved to client:
      const allMsgs = [...sentSnap.docs, ...receivedSnap.docs].map(d => d.data());
      allMsgs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); // Descending
  
      allMsgs.forEach(msg => {
        if (msg.senderId === userId) partners.add(msg.receiverId);
        else partners.add(msg.senderId);
      });
      
      return Array.from(partners);
    } catch (e) { return []; }
  }

  async getMessages(user1Id: string, user2Id: string): Promise<ChatMessage[]> {
    try {
      const q1 = query(collection(firestore, 'messages'), where('senderId', '==', user1Id), where('receiverId', '==', user2Id));
      const q2 = query(collection(firestore, 'messages'), where('senderId', '==', user2Id), where('receiverId', '==', user1Id));
      
      const [snap1, snap2] = await Promise.all([getDocs(q1), getDocs(q2)]);
      const msgs = [...snap1.docs, ...snap2.docs]
        .map(d => ({ id: d.id, ...d.data() } as ChatMessage))
        .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        
      return msgs;
    } catch (e) { return []; }
  }

  // Live Listeners for Chat
  subscribeToRecentChats(userId: string, callback: (partners: string[]) => void): Unsubscribe {
    if (!userId) return () => {};
    
    // We listen to sent and received messages separately
    // Removed limit(50) to avoid potential Firestore internal assertion errors with onSnapshot
    const sentQ = query(collection(firestore, 'messages'), where('senderId', '==', userId));
    const receivedQ = query(collection(firestore, 'messages'), where('receiverId', '==', userId));

    let sentData: any[] = [];
    let receivedData: any[] = [];

    const process = () => {
      const allMsgs = [...sentData, ...receivedData];
      allMsgs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      const partners = new Set<string>();
      allMsgs.forEach(msg => {
        if (msg.senderId === userId) partners.add(msg.receiverId);
        else partners.add(msg.senderId);
      });
      callback(Array.from(partners));
    };

    const unsub1 = onSnapshot(sentQ, (snap) => {
      sentData = snap.docs.map(d => d.data());
      process();
    }, (error) => {
      console.warn("Recent chats (sent) snapshot error:", error.code);
    });
    const unsub2 = onSnapshot(receivedQ, (snap) => {
      receivedData = snap.docs.map(d => d.data());
      process();
    }, (error) => {
      console.warn("Recent chats (received) snapshot error:", error.code);
    });

    return () => { unsub1(); unsub2(); };
  }

  subscribeToMessages(user1Id: string, user2Id: string, callback: (msgs: ChatMessage[]) => void): Unsubscribe {
    if (!user1Id || !user2Id) return () => {};

    const q1 = query(collection(firestore, 'messages'), where('senderId', '==', user1Id), where('receiverId', '==', user2Id));
    const q2 = query(collection(firestore, 'messages'), where('senderId', '==', user2Id), where('receiverId', '==', user1Id));

    let msgs1: ChatMessage[] = [];
    let msgs2: ChatMessage[] = [];

    const process = () => {
      const combined = [...msgs1, ...msgs2].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      callback(combined);
    };

    const unsub1 = onSnapshot(q1, (snap) => {
      msgs1 = snap.docs.map(d => ({ id: d.id, ...d.data() } as ChatMessage));
      process();
    }, (error) => {
      console.warn("Messages (q1) snapshot error:", error.code);
    });
    const unsub2 = onSnapshot(q2, (snap) => {
      msgs2 = snap.docs.map(d => ({ id: d.id, ...d.data() } as ChatMessage));
      process();
    }, (error) => {
      console.warn("Messages (q2) snapshot error:", error.code);
    });

    return () => { unsub1(); unsub2(); };
  }

  async getFriendRequests(userId: string): Promise<FriendRequest[]> {
    try {
      const q = query(collection(firestore, 'friend_requests'), where('receiverId', '==', userId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as FriendRequest));
    } catch (e) { return []; }
  }

  subscribeToFriendRequests(userId: string, callback: (reqs: FriendRequest[]) => void): Unsubscribe {
    const q = query(collection(firestore, 'friend_requests'), where('receiverId', '==', userId));
    return onSnapshot(q, (snap) => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as FriendRequest)));
    }, (error) => {
      console.warn("Friend requests snapshot error:", error.code);
    });
  }

  async getSentFriendRequests(userId: string): Promise<FriendRequest[]> {
    try {
      const q = query(collection(firestore, 'friend_requests'), where('senderId', '==', userId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as FriendRequest));
    } catch (e) { return []; }
  }

  subscribeToSentFriendRequests(userId: string, callback: (reqs: FriendRequest[]) => void): Unsubscribe {
    const q = query(collection(firestore, 'friend_requests'), where('senderId', '==', userId));
    return onSnapshot(q, (snap) => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as FriendRequest)));
    }, (error) => {
      console.warn("Sent friend requests snapshot error:", error.code);
    });
  }

  async sendFriendRequest(sender: User, receiverId: string) {
    await addDoc(collection(firestore, 'friend_requests'), {
      senderId: sender.id,
      senderName: sender.displayName,
      senderUsername: sender.username,
      senderAvatar: sender.avatar,
      receiverId,
      status: 'pending',
      createdAt: new Date().toISOString()
    });
  }

  async acceptFriendRequest(request: FriendRequest, userName: string) {
    await addDoc(collection(firestore, 'friendships'), {
      user1Id: request.senderId,
      user2Id: request.receiverId,
      createdAt: new Date().toISOString()
    });
    await deleteDoc(doc(firestore, 'friend_requests', request.id));
    await this.sendNotification(request.senderId, 'طلب صداقة', `قام ${userName} بقبول طلب الصداقة`, 'friend_request', 'UserPlus');
  }

  async rejectFriendRequest(id: string) { await deleteDoc(doc(firestore, 'friend_requests', id)); }
  async cancelFriendRequest(id: string) { await deleteDoc(doc(firestore, 'friend_requests', id)); }

  async getGameInvites(): Promise<GameInvite[]> {
    const q = query(collection(firestore, 'game_invites'), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as GameInvite));
  }

  subscribeToGameInvites(callback: (invites: GameInvite[]) => void): Unsubscribe {
    const q = query(collection(firestore, 'game_invites'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snap) => {
      callback(snap.docs.map(d => ({ id: d.id, ...d.data() } as GameInvite)));
    });
  }

  async createGameInvite(user: User, mcName: string, version: string, expiresAt: string) {
    await addDoc(collection(firestore, 'game_invites'), {
      hostId: user.id,
      hostName: user.displayName,
      hostAvatar: user.avatar,
      mcName,
      version,
      expiresAt,
      createdAt: new Date().toISOString()
    });
  }

  async acceptGameInvite(userId: string, hostId: string, mcName: string) {
    await this.sendMessage(userId, hostId, `مرحباً، أرغب في الانضمام لدعوتك! اسمي في اللعبة: ${mcName}`);
  }

  async deleteGameInvite(id: string) { await deleteDoc(doc(firestore, 'game_invites', id)); }
  
  async postNews(news: Partial<NewsItem>) { await addDoc(collection(firestore, 'news'), { ...news, createdAt: new Date().toISOString() }); }
  async deleteNews(id: string) { await deleteDoc(doc(firestore, 'news', id)); }
  async deleteServer(id: string) { await deleteDoc(doc(firestore, 'servers', id)); }
  async getStaffMessages(): Promise<StaffMessage[]> { const q = query(collection(firestore, 'staff_messages'), orderBy('createdAt', 'desc'), limit(50)); const snap = await getDocs(q); return snap.docs.map(d => ({ id: d.id, ...d.data() } as StaffMessage)).reverse(); }
  async sendStaffMessage(user: User, text: string) { await addDoc(collection(firestore, 'staff_messages'), { userId: user.id, userName: user.displayName, userAvatar: user.avatar, userRole: user.role, text, createdAt: new Date().toISOString() }); }
  async getSiteSettings() { const snap = await getDoc(doc(firestore, 'settings', 'site')); return snap.exists() ? snap.data() : {}; }
  generateAdminCode(): string { return 'AC-' + Math.random().toString(36).substr(2, 8).toUpperCase(); }
  async updatePermissions(userId: string, permissions: AdminPermissions, role: UserRole, code?: string) { const data: any = { adminPermissions: permissions, role }; if (code) data.adminCode = code; await updateDoc(doc(firestore, 'users', userId), data); }
  async createComplaint(userId: string, username: string, subject: string, message: string) { await addDoc(collection(firestore, 'complaints'), { userId, username, subject, message, status: 'pending', createdAt: new Date().toISOString() }); }
  async resolveComplaint(id: string) { await updateDoc(doc(firestore, 'complaints', id), { status: 'resolved' }); }
  async deleteComplaint(id: string) { await deleteDoc(doc(firestore, 'complaints', id)); }
  async setSecurityCode(userId: string, code: string, frequency: number) { await updateDoc(doc(firestore, 'users', userId), { securityCode: code, securityCodeFrequency: frequency, loginsSinceLastCode: 0 }); }
  async removeSecurityCode(userId: string) { await updateDoc(doc(firestore, 'users', userId), { securityCode: deleteField(), securityCodeFrequency: deleteField(), loginsSinceLastCode: deleteField() }); }
  async verifySecurityCheck(userId: string) { await updateDoc(doc(firestore, 'users', userId), { loginsSinceLastCode: 0 }); }

  async getPurchasedMods(userId: string): Promise<Mod[]> {
    const q = query(collection(firestore, 'purchases'), where('userId', '==', userId));
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data().modSnapshot as Mod);
  }

  async getFriends(userId: string): Promise<string[]> {
    const q1 = query(collection(firestore, 'friendships'), where('user1Id', '==', userId));
    const q2 = query(collection(firestore, 'friendships'), where('user2Id', '==', userId));
    const [s1, s2] = await Promise.all([getDocs(q1), getDocs(q2)]);
    const friends = new Set<string>();
    s1.docs.forEach(d => friends.add(d.data().user2Id));
    s2.docs.forEach(d => friends.add(d.data().user1Id));
    return Array.from(friends);
  }

  async sendMessage(senderId: string, receiverId: string, text: string) {
    await addDoc(collection(firestore, 'messages'), {
      senderId,
      receiverId,
      text,
      createdAt: new Date().toISOString()
    });
  }

  async blockUser(blockerId: string, blockedId: string) {
    await updateDoc(doc(firestore, 'users', blockerId), {
      blockedUsers: arrayUnion(blockedId)
    });
  }

  async unblockUser(blockerId: string, blockedId: string) {
    await updateDoc(doc(firestore, 'users', blockerId), {
      blockedUsers: arrayRemove(blockedId)
    });
  }

  async hideChat(userId: string, targetId: string) {
    await updateDoc(doc(firestore, 'users', userId), {
      hiddenChats: arrayUnion(targetId)
    });
  }

  async sendVerificationEmail() {
    if (auth.currentUser) {
      await sendEmailVerification(auth.currentUser);
      return true;
    }
    return false;
  }

  async sendPasswordReset(email: string) {
    await sendPasswordResetEmail(auth, email);
  }

  async hasPurchased(userId: string, modId: string): Promise<boolean> {
    const q = query(collection(firestore, 'purchases'), where('userId', '==', userId), where('modId', '==', modId));
    const snap = await getDocs(q);
    return !snap.empty;
  }

  async likeMod(modId: string, userId: string) {
    const ref = doc(firestore, 'mods', modId);
    await runTransaction(firestore, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const data = snap.data() as Mod;
      const likes = data.likedBy || [];
      const dislikes = data.dislikedBy || [];
      
      let newLikes = likes;
      let newDislikes = dislikes;
      let likesCount = data.stats.likes;
      let dislikesCount = data.stats.dislikes;

      if (likes.includes(userId)) {
        newLikes = likes.filter(id => id !== userId);
        likesCount--;
      } else {
        newLikes = [...likes, userId];
        likesCount++;
        if (dislikes.includes(userId)) {
          newDislikes = dislikes.filter(id => id !== userId);
          dislikesCount--;
        }
      }
      
      tx.update(ref, { 
        likedBy: newLikes, 
        dislikedBy: newDislikes,
        'stats.likes': likesCount,
        'stats.dislikes': dislikesCount
      });
    });
  }

  async dislikeMod(modId: string, userId: string) {
    const ref = doc(firestore, 'mods', modId);
    await runTransaction(firestore, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const data = snap.data() as Mod;
      const likes = data.likedBy || [];
      const dislikes = data.dislikedBy || [];
      
      let newLikes = likes;
      let newDislikes = dislikes;
      let likesCount = data.stats.likes;
      let dislikesCount = data.stats.dislikes;

      if (dislikes.includes(userId)) {
        newDislikes = dislikes.filter(id => id !== userId);
        dislikesCount--;
      } else {
        newDislikes = [...dislikes, userId];
        dislikesCount++;
        if (likes.includes(userId)) {
          newLikes = likes.filter(id => id !== userId);
          likesCount--;
        }
      }
      
      tx.update(ref, { 
        likedBy: newLikes, 
        dislikedBy: newDislikes,
        'stats.likes': likesCount,
        'stats.dislikes': dislikesCount
      });
    });
  }

  async rateMod(modId: string, userId: string, rating: number) {
    const ref = doc(firestore, 'mods', modId);
    await runTransaction(firestore, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const data = snap.data() as Mod;
      const ratedBy = data.ratedBy || {};
      const oldRating = ratedBy[userId] || 0;
      
      ratedBy[userId] = rating;
      
      let totalScore = data.stats.totalRatingScore || 0;
      let count = data.stats.ratingCount || 0;
      
      if (oldRating === 0) {
        count++;
        totalScore += rating;
      } else {
        totalScore = totalScore - oldRating + rating;
      }
      
      const averageRating = count > 0 ? Number((totalScore / count).toFixed(1)) : 0;
      
      tx.update(ref, {
        ratedBy,
        'stats.totalRatingScore': totalScore,
        'stats.ratingCount': count,
        'stats.averageRating': averageRating
      });
    });
  }

  async recordDownload(userId: string, mod: Mod) {
    await setDoc(doc(firestore, 'user_downloads', `${userId}_${mod.id}`), {
      userId,
      modId: mod.id,
      modSnapshot: mod,
      timestamp: serverTimestamp()
    });
  }

  async purchaseMod(user: User, mod: Mod) {
    if (!mod.price) return;
    const userRef = doc(firestore, 'users', user.id);
    await runTransaction(firestore, async (tx) => {
      const uSnap = await tx.get(userRef);
      if (!uSnap.exists()) throw new Error("User not found");
      const uData = uSnap.data() as User;
      const balance = (uData.wallet?.gift || 0) + (uData.wallet?.earned || 0);
      if (balance < mod.price!) throw new Error("رصيد غير كافي");
      
      let remainingCost = mod.price!;
      let newGift = uData.wallet?.gift || 0;
      let newEarned = uData.wallet?.earned || 0;
      
      if (newGift >= remainingCost) {
        newGift -= remainingCost;
      } else {
        remainingCost -= newGift;
        newGift = 0;
        newEarned -= remainingCost;
      }
      
      tx.update(userRef, { 'wallet.gift': newGift, 'wallet.earned': newEarned });
      
      const purchaseRef = doc(collection(firestore, 'purchases'));
      tx.set(purchaseRef, {
        userId: user.id,
        modId: mod.id,
        price: mod.price,
        modSnapshot: mod,
        timestamp: serverTimestamp()
      });
      
      const publisherRef = doc(firestore, 'users', mod.publisherId);
      const commission = mod.price! * COMMISSION_RATE;
      const earnings = mod.price! - commission;
      tx.update(publisherRef, { 'wallet.earned': increment(earnings) });
    });
  }
}

export const db = new PlatformDB();